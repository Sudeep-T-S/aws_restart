mystring='this is my string'
print(mystring)
print(type(mystring))
print(mystring," is of the data type",str(type(mystring)))
firststring="water"
secondstring="fall"
thridstring=firststring+secondstring
print(thridstring)
name=input("whats your name   ")
print('hello',   name)
color=input('what is your favourite color ?')
animal=input('what is your favourite animal?')
print('{},you like a {} and  {}!'.format(name,color,animal))